|dominio|formato|coletar|isolar|remover|
|-----------|-----------|-----------|-----------|-----------|
|https://rr.sapo.pt|html|div class="all-100" id="bodyDinamico"|div class="OutlineElement Ltr SCXW251438329 BCX0;div class='card-body-1'||
|https://www.cnnbrasil.com.br|script|script type="application/ld+json"|articleBody||
|https://www.voaportugues.com|html|div class="wsw"|span class="dateline";div class="media-block__content also-read__body also-read__body--h";div id="comments" class="comments-parent";div class="comments-form comments-external";h3 class="section-head";div class="comments comments--ext";noscript;span class="also-read__text--label";span class="label label--share";div class="hdr-container";span class="also-read__text--label"||
|https://www.rfi.fr|html|html|||
|https://www.dn.pt|html|html|||
|https://www.rtp.pt|html|p itemprop="text" class="article-body"|||
|https://observador.pt|html|div class="article-body-content"|||
|https://www.publico.pt|html|div class="story__body"|||
|https://sicnoticias.pt|script|script id="gs-init-info"|||
|https://eco.sapo.pt|html|div class="entry__content"|button class="comment__more";p class="quote-author__description";cite class="quote-author__name"||
|https://visao.pt|html|div class="entry-content"|||
|https://capmagellan.com|html|div class="post-wrapper-content"|span class="s1"||
|https://www.poder360.com.br|html|<div class="inner-page-section__text">|||
|https://g1.globo.com|html|main class="mc-body theme"|||
|https://cnnportugal.iol.pt|html|div class="article-conteudo" id="articleContent"|||