import os
import datetime
import shutil
from grava_arquivo import*

def le_lista_fontes():
    log_erros=[]
    arquivos = os.listdir("fonte")
    if "lista_fontes.txt" not in arquivos:
        print("""Arquivo "fonte/lista_fontes.txt" não encontrado.\nCertifique-se de que um arquivo com o nome correto esteja no ficheiro correto.\n""")
    else:
        print("""Arquivo "fonte/lista_fontes.txt" encontrado.\nLendo arquivo...\n""")
        with open ("fonte/lista_fontes.txt", "r", encoding="utf-8") as arquivo:
            fontes = arquivo.read()
        lista_fontes=fontes.splitlines()
        lidos=[]
        for fonte in lista_fontes:
            linha=lista_fontes.index(fonte)
            if fonte.startswith("novo - "):
                try:
                    indice = fonte.index(":")-1
                except Exception as e:
                    link=(f"Não foi possivel coletar o link da string '{fonte}'")
                    lista_fontes[linha]=fonte.replace("novo - ","NOK - ")
                    log_erros.append([lista_fontes[linha],link])
                if "s" not in fonte [indice] and "p" not in fonte [indice]:
                    link=(f"Não foi possivel coletar o link da string '{fonte}'")
                    lista_fontes[linha]=fonte.replace("novo - ","NOK - ")
                    log_erros.append([lista_fontes[linha],link])
                else:
                    if "s" in fonte[indice]:
                        link=fonte[indice-4:]
                    if "p" in fonte[indice]:
                        link=fonte[indice-3:]
                    #lista_fontes[linha]=fonte.replace("novo - ","lido - ")
                    lidos.append(lista_fontes[linha].split(" - "))
        data=str(datetime.datetime.now())
        data=data.replace(":","")
        shutil.copy("fonte/lista_fontes.txt", "log/lista_fontes_entrada_"+data+".txt")

        grava_resultado(lista_fontes,"lista_fontes.txt","w","fonte")
        #grava_resultado(log_erros,"log_erros_"+data+".txt","log")
    return(lidos)
