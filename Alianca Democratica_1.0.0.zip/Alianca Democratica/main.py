from le_arquivo import*
from web_scrapping import*
from pdf_scrapping import*
import subprocess

pdf_scrapping()

#extrai_oficial()

#fontes=le_lista_fontes()

#extrai_texto(fontes)
