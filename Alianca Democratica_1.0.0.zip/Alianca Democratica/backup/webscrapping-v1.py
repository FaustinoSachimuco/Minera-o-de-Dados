#import requests
#from bs4 import BeautifulSoup
#from grava_arquivo import *

#def capturar_texto(site,nomearquivo):
#    response = requests.get(site)
#    if response.status_code == 200: # Verificando se a solicitação foi bem sucedida (código 200)
#        soup = BeautifulSoup(response.content, 'html.parser')
#        texto = soup.get_text() #Coleta o texto da página
#        grava_arquivo_txt("raw/"+nomearquivo,texto)
#    else:
#        print("Erro ao fazer a solicitação HTTP: ", response.status_code)