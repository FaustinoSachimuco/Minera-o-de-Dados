from jjcli import *
from bs4 import BeautifulSoup
from bs4 import BeautifulSoup as bs
import requests
import subprocess
from le_arquivo import*
from selenium import webdriver

def extrai_texto(fontes):
    session = requests.Session()

    def coleta(link, indice):
        try:
            response = requests.get(link)
            if response.status_code == 200: # Verificando se a solicitação foi bem sucedida (código 200)
                raw = str(BeautifulSoup(response.content, 'html.parser'))
                #texto = soup.get_text() #Coleta o texto da página
                #grava_arquivo_txt("raw/"+nomearquivo,texto)
                grava_resultado(raw,"arquivo"+indice+".html","raw")
            else:
                print("Erro ao fazer a solicitação HTTP: ", response.status_code)
        except Exception as e:
            pass

    def coleta_v2(link, indice):
        try:
            driver = webdriver.Chrome()  # Ou outro navegador suportado pelo Selenium
            driver.get(link)
            raw = driver.find_element_by_tag_name('body').text
            #print(raw)
            grava_resultado(raw,"arquivo"+indice+".html","raw")
            driver.quit()
        except Exception as e:
            pass

    def coleta_v3(link):
        link = "https://www.rfi.fr/pt/mundo/20240311-alian%C3%A7a-democr%C3%A1tica-ganha-por-pouco-e-chega-consegue-eleger-48-deputados"
        comando = f'wget -r -c -l 2 {link}'
        subprocess.run(comando)

    def extracao():
        #print("BUSCANDO NOS HTMLS..............................")
        conteudo_raw= glob("raw/arquivo*.html")
        #print (conteudo_raw)
        for arquivo in conteudo_raw:
            with open(arquivo, encoding="utf-8") as arq:
                html= arq.read()
            a=bs(html) # cria uma árvore documental






            if a.find("div", id="article-content"):artigo= a.find("div", id="article-content")
            if a.find("div", id="block-psd-content"):artigo= a.find("div", id="block-psd-content")
            if a.find("div", id="bodyDinamico"):artigo= a.find("div", id="bodyDinamico")
            if a.find("div", id="content"):artigo= a.find("div", id="content")

            remove_tag_lixo('h3', "section-head")
            remove_tag_lixo('span', "also-read__text--label")
            remove_tag_lixo('div', "OutlineElement Ltr SCXW251438329 BCX0")
            remove_tag_lixo('div', "card-body-1")
            remove_tag_lixo('noscript',None)
            remove_tag_lixo('class',"media-block also-read")
            remove_tag_lixo('class',"also-read__text--label")
            remove_tag_lixo('class',"label label--share")

            #texto=[]

            if a.find_all("script", type="application/ld+json"):
                artigos= a.find_all("script", type="application/ld+json")
                for artigo in artigos:
                    if "articleBody" in artigo.get_text():
                        texto=(artigo.get_text())
            else:
                texto=(artigo.get_text())

            def remove_tag_lixo(tipo_tag,class_tag):
            #REMOVENDO OCORRENCIAS INDESEJADAS
                try:
                    for tag in artigo.find_all(tipo_tag, class_=class_tag):
                        tag.decompose()
                except Exception as e:
                    pass

            if "articleBody" in texto:
                parte_texto=texto.split('"')
                i=parte_texto.index("articleBody")
                texto=(parte_texto[i+2])
                texto=re.sub(r'\.', '.\n', texto)

            texto_linhas=texto.splitlines()
            texto_limpo=[]
            #texto_limpo.append(f"--------------------------------------{arquivo}--------------------------------------")
            for linha in texto_linhas:
                linha=re.sub(r'\s+', ' ', linha)
                linha=re.sub(r'\t+', ' ', linha)
                if len(linha)>0:
                    texto_limpo.append(f"{linha}")

            #AQUI PODE GRAVAR TUDO EM UM SÓ ARQUIVO
            #grava_resultado(texto_limpo,"arquivo"+arquivo[5:-5]+".txt","raw_txt")
            grava_resultado(texto_limpo,"TEXTO_SAIDA.txt","TEXTO_SAIDA") 
            texto_limpo.clear()
                    
    for item in fontes:
        indice = fontes.index(item)
        coleta(item[2], str(indice))
        #coleta_v2(item[2], str(indice))
        coleta_v3(item[2])
    extracao()
    print("Extração Completa")


def busca_divs():
    conteudo_raw= glob("raw/arquivo*.html")
    for arquivo in conteudo_raw:
        grava_resultado(f"\n\n\n----------------------{arquivo}","divs.txt","reportDivs")
        with open(arquivo, encoding="utf-8") as arq:
            html= arq.read()
        soup = BeautifulSoup(html, 'html.parser')
        divs = soup.find_all('div', id=lambda x: x and 'conte' in x)
        for div in divs:
            div_id = div.get('id')
            if div_id:  # Verifica se a div possui ID
                grava_resultado(f"\nID da div: {div_id}", "divs.txt","reportDivs")
        