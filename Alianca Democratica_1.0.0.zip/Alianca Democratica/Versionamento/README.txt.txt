Versão1.0.0:

Capaz de requisitar sites com REQUEST e obter o conteúdo em HTML.
Grava os arquivs HTML e com o Beautiful Soup, extrai as tags que interessam, fazendo limpeza das que não importam.
Há um problema nesta versão: num dos sites baixados os textos de tags indesejadas não excluídos conforme esperado.


Versão 1.1.2:
Correção do bug de limpeza das tags indesejadas das coletas que já funcionam.