from jjcli import *
from bs4 import BeautifulSoup
from bs4 import BeautifulSoup as bs
import requests
import subprocess
from le_arquivo import*
from selenium import webdriver


def extrai_oficial():
    session = requests.Session()

    def extracao_oficial():
        #BUSCANDO NO SITE OFICIAL:

        def extrai_pagina(endereco, tag_pagina, class_pagina, destino_texto):
            with open(f"{endereco}","r",encoding="utf-8") as arq:
                html=arq.read()                
            a=bs(html) # cria uma árvore documental


            if a.find(tag_pagina, class_=class_pagina):
                artigo=a.find_all(tag_pagina, class_=class_pagina)
                for item in artigo:
                    print(item.get_text())
                    texto=item.get_text()
                    linhas_texto=texto.splitlines()
                    for linha in linhas_texto:
                        if linha.strip():
                            grava_resultado(f"{linha}\n",destino_texto,"raw_txt")
                            grava_resultado(f"{linha}\n","TEXTO_SAIDA.txt","TEXTO_SAIDA") 

        #Apoios:
        endereco="raw/ad2024.pt/apoios"
        extrai_pagina(endereco,"p","card-text small","cards_apoio.txt")

        #Hino:
        endereco="raw/ad2024.pt/videos/hino-da-alianca-democratica"
        extrai_pagina(endereco,"div","social-text","hino.txt")

        #Noticias:
        endereco="raw/ad2024.pt/noticias/*"
        conteudo_raw=glob(endereco)
        for item in conteudo_raw:
            extrai_pagina(item,"div","news-card","noticias.txt")       

    extracao_oficial()
    print("Extração Completa")





def extrai_texto(fontes):
    session = requests.Session()

    def coleta(link, indice):
        try:
            response = requests.get(link)
            if response.status_code == 200: # Verificando se a solicitação foi bem sucedida (código 200)
                raw = str(BeautifulSoup(response.content, 'html.parser'))
                #texto = soup.get_text() #Coleta o texto da página
                #grava_arquivo_txt("raw/"+nomearquivo,texto)
                grava_resultado(raw,"arquivo"+indice+".html","raw")
            else:
                print("Erro ao fazer a solicitação HTTP: ", response.status_code)
        except Exception as e:
            pass

    #def coleta_v2(link, indice):
    #    try:
    #        driver = webdriver.Chrome()  # Ou outro navegador suportado pelo Selenium
    #        driver.get(link)
    #        raw = driver.find_element_by_tag_name('body').text
    #        #print(raw)
    #        grava_resultado(raw,"arquivo"+indice+".html","raw")
    #        driver.quit()
    #    except Exception as e:
    #        pass

    #def coleta_v3(link):
    #    link = "https://www.rfi.fr/pt/mundo/20240311-alian%C3%A7a-democr%C3%A1tica-ganha-por-pouco-e-chega-consegue-eleger-48-deputados"
    #    comando = f'wget -r -c -l 2 {link}'
    #    subprocess.run(comando)

    def extracao():

        #print("BUSCANDO NOS HTMLS..............................")
        conteudo_raw= glob("raw/arquivo*.html")



        #print (conteudo_raw)
        for arquivo in conteudo_raw:
            with open(arquivo, encoding="utf-8") as arq:
                html= arq.read()
            a=bs(html) # cria uma árvore documental

            def remove_tag_lixo(tipo_tag,class_tag, tag_id):
            #REMOVENDO OCORRENCIAS INDESEJADAS
                try:
                    for tag in artigo.find_all(tipo_tag, class_=class_tag, id=tag_id):
                        tag.decompose()
                except Exception as e:
                    pass

            #DE REPORTAGENS ONLINE
            if a.find("div", class_="inner-page-section__text"):artigo=a.find("div", class_="inner-page-section__text")
            if a.find("div", class_="wsw"):artigo=a.find("div", class_="wsw")
            if a.find("div", id="content"):artigo= a.find("div", id="content")
            if a.find("div", class_="content"):artigo= a.find("div", class_="content")
            if a.find("div", class_="story__body"):artigo=a.find("div", class_="story__body")
            if a.find("div", id="article-content"):artigo= a.find("div", id="article-content")
            if a.find("div", class_="article-conteudo"):artigo=a.find("div", class_="article-conteudo")
            #if a.find("div", id="block-psd-content"): artigo=a.find("div", id="block-psd-content")
            if a.find("div", id="bodyDinamico"):artigo= a.find("div", id="bodyDinamico")
            if a.find("div", class_="story__body"):artigo=a.find("div", class_="story__body")
            if a.find("div", id="article-content-data"):artigo=a.find("div", id="article-content-data")
            if a.find("div", class_="entry__content"):artigo=a.find("div", class_="entry__content")
            if a.find("div", class_="mc-column content-media__container"):artigo=a.find("div", class_="mc-column content-media__container")
            if a.find("div", class_="inner-page-section__text"):artigo= a.find("div", class_="inner-page-section__text")
            if a.find("div", class_="post-wrapper-content"):artigo= a.find("div", class_="post-wrapper-content")
            if a.find("meta", content="article"):artigo=a.find("meta", content="article")
            if a.find("div", class_="sas-wrapper"):artigo=a.find("div", class_="sas-wrapper")
            if a.find("p", class_="article-body"):artigo=a.find("p", class_="article-body")
            if a.find("div",class_="site body__wrapper"):artigo=a.find("div",class_="site body__wrapper")
            

            remove_tag_lixo('span',"dateline",None)
            remove_tag_lixo('div',"media-block__content also-read__body also-read__body--h",None)
            remove_tag_lixo('div', "comments-parent", "comments")
            remove_tag_lixo('div',"share-url",None)
            remove_tag_lixo('h2',"info_title", None)
            remove_tag_lixo('div',"trending__list-container", None)
            remove_tag_lixo('div',"card--trending trending", None)
            remove_tag_lixo('ul',"primary-menu","menu-menu-principal")
            remove_tag_lixo('ul',"meta__info",None)
            remove_tag_lixo('p',"info-card__link", None)
            remove_tag_lixo('div',"comments-form comments-external",None)
            remove_tag_lixo('h3', "section-head",None)
            remove_tag_lixo('div',"comments comments--ext",None)
            remove_tag_lixo('div', "OutlineElement Ltr SCXW251438329 BCX0", None)
            remove_tag_lixo('div', "card-body-1",None)
            remove_tag_lixo('noscript',None, None)
            remove_tag_lixo('div',"media-block also-read", None)
            remove_tag_lixo('div',"also-read__text--label",None)
            remove_tag_lixo('div',"label label--share",None)
            remove_tag_lixo('div', "hdr-container",None)
            remove_tag_lixo('script', None,None)
            remove_tag_lixo('span', "also-read__text--label", None)
            remove_tag_lixo('div',"article-info",None)
            remove_tag_lixo('div',"rticle-authors",None)
            remove_tag_lixo('div',"paywall*",None)
            remove_tag_lixo('div',"sidebar-wrapper",None)
            remove_tag_lixo('div',"collapsible",None)
            remove_tag_lixo('div',"info",None)
            remove_tag_lixo('div', "paywall-blocker-head",None)
            remove_tag_lixo('div', "paywall-blocker-body",None)
            remove_tag_lixo('div',"article-authors",None)
            #remove_tag_lixo('fieldset',None,None)

            #texto=[]

            try:
                texto=(artigo.get_text())
            except Exception as e:
                pass

            #print("Finding ARTIGOS...\n\n\n")
            if a.find_all("script", type="application/ld+json"):
                artigos= a.find_all("script", type="application/ld+json")
                for artigo in artigos:
                    if "articleBody" in artigo.get_text():
                        texto=(artigo.get_text())


            if "articleBody" in texto:
                parte_texto=texto.split('"')
                i=parte_texto.index("articleBody")
                texto=(parte_texto[i+2])
                texto=re.sub(r'\.', '.\n', texto)

            try: 
                texto_linhas=texto.splitlines()
            except Exception as e:
                pass

            texto_limpo=[]
            #texto_limpo.append(f"--------------------------------------{arquivo}--------------------------------------")
            try:
                for linha in texto_linhas:
                    linha=re.sub(r'\s+', ' ', linha)
                    linha=re.sub(r'\t+', ' ', linha)
                    if len(linha)>0 and linha!=" ":
                        texto_limpo.append(f"{linha}")
            except Exception as e:
                pass
            #AQUI PODE GRAVAR TUDO EM UM SÓ ARQUIVO
            grava_resultado(texto_limpo,"arquivo"+arquivo[5:-5]+".txt","raw_txt")
            grava_resultado(texto_limpo,"TEXTO_SAIDA.txt","TEXTO_SAIDA") 
            texto_limpo.clear()

    for item in fontes:
        indice = fontes.index(item)
        coleta(item[2], str(indice))
        #coleta_v2(item[2], str(indice))
        #coleta_v3(item[2])
    extracao()
    print("Extração Completa")