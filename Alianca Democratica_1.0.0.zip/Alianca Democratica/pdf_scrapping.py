from PyPDF2 import PdfReader
from grava_arquivo import*

def pdf_scrapping():
    texto = ""
    with open("raw/pdf/ad-programa-eleitoral.pdf", "rb") as arquivo:
        leitor_pdf = PdfReader(arquivo)
        num_paginas = len(leitor_pdf.pages)
        for pagina in range(7,num_paginas):
            texto = leitor_pdf.pages[pagina].extract_text()
            texto_pagina=texto.splitlines()
            texto_limpo=[]
            for linha in texto_pagina:
                if linha.isupper():
                    linha=linha.lower()
                if linha.startswith("• "):
                    linha=linha[2:]
                if linha.startswith("Executivo") or linha.startswith("eleitoral20") or linha.startswith("programa") or linha[0].isdigit():
                    linha=""
                if linha!="":
                    print(linha)
                    grava_resultado(f"{linha}\n","ad-programa-eleitoral.txt","raw_txt")
                    grava_resultado(f"{linha}\n","TEXTO_SAIDA.txt","TEXTO_SAIDA") 