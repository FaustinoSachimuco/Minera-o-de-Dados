from jjcli import * # type: ignore
from bs4 import BeautifulSoup # type: ignore
from bs4 import BeautifulSoup as bs # type: ignore
import requests # type: ignore
import subprocess
from le_arquivo import*
from selenium import webdriver # type: ignore

#EXTRAI DAS TRANSCRIÇÕES DE VIDEOS
def extrai_transcricoes():
    transcricoes = os.listdir("raw/discursos")
    for arquivo in transcricoes:
        with open("raw/discursos/"+arquivo, encoding="utf-8") as arq_transcricao:
            transcricao=arq_transcricao.read()
            transcricao.replace("[Música]", "")
            transcricao.replace("[Aplausos]", "")
            txt_transcricao=transcricao.split()
            for i in range(0, len(txt_transcricao), 25):
                linha=' '.join(txt_transcricao[i:i+25])
                grava_resultado(f"{linha}\n","TEXTO_SAIDA.txt","a","TEXTO_SAIDA")


#EXTRAÇÕES DO SITE OFICIAL DA ALIANÇA DEMOCRÁTICA
def extrai_oficial():
    session = requests.Session()

    def extracao_oficial():
        #BUSCANDO NO SITE OFICIAL:

        def extrai_pagina(endereco, tag_pagina, class_pagina, destino_texto):
            with open(f"{endereco}","r",encoding="utf-8") as arq:
                html=arq.read()
            a=bs(html) # cria uma árvore documental


            if a.find(tag_pagina, class_=class_pagina):
                artigo=a.find_all(tag_pagina, class_=class_pagina)
                for item in artigo:
                    print(item.get_text())
                    texto=item.get_text()
                    linhas_texto=texto.splitlines()
                    for linha in linhas_texto:
                        if linha.strip():
                            grava_resultado(f"{linha}\n",destino_texto,"a","raw_txt")
                            grava_resultado(f"{linha}\n","TEXTO_SAIDA.txt","a","TEXTO_SAIDA")

        #Apoios:
        endereco="raw/ad2024.pt/apoios"
        extrai_pagina(endereco,"p","card-text small","cards_apoio.txt")

        #Hino:
        endereco="raw/ad2024.pt/videos/hino-da-alianca-democratica"
        extrai_pagina(endereco,"div","social-text","hino.txt")

        #Noticias:
        endereco="raw/ad2024.pt/noticias/*"
        conteudo_raw=glob(endereco)
        for item in conteudo_raw:
            extrai_pagina(item,"div","news-card","noticias.txt")

    extracao_oficial()
    print("Extração Completa")


#EXTRAÇÕES DE REPORTAGENS ONLINE SOBRE A ALIANÇA DEMOCRÁTICA NAS ELEIÇÕES DE 2024
def extrai_texto(fontes):

    #CARREGA A LISTA DE REFERÊNCIAS INDICANDO QUE TAG DEVE SER EXTRAÍDA DE QUE PADRÃO DE SITE
    def carrega_referencias():
        lista_referencias=[]
        with open ("sites.md", "r", encoding="utf-8") as arquivo:
            referencias=arquivo.read().splitlines()
            for referencia in referencias[2:]:
                lista_referencias.append(referencia.split("|")[1:-1])
        return lista_referencias
    
    #PRIMEIRO REQUISITA OS HTMLS E GRAVA LOCALMENTE
    def coleta(link, referencia,exclusoes):
        try:
            response = requests.get(link)
            print(f"\n-------------------------{link}...")
            if response.status_code == 200: # Verificando se a solicitação foi bem sucedida (código 200)
                raw = str(BeautifulSoup(response.content, 'html.parser'))
                #texto = soup.get_text() #Coleta o texto da página
                #grava_arquivo_txt("raw/"+nomearquivo,texto)
                #print(f"\n-------------------------{raw}")
                grava_resultado(raw,"temp.html","w","raw")
                extracao(link,referencia,exclusoes)
            else:
                print("Erro ao fazer a solicitação HTTP: ", response.status_code)
        except Exception as e:
            pass

    #A EXTRAÇÃO É FEITA DOS HTMLS REQUISITADOS
    def extracao(link,referencia,exclusoes):

        conteudo_raw= glob("raw/temp.html")
        
        for arquivo in conteudo_raw:
            with open(arquivo, encoding="utf-8") as arq:
                html= arq.read()
            a=bs(html) # cria uma árvore documental

            #DE REPORTAGENS ONLINE
            #Aqui, vai buscar a referencia de que tag tem que coletar na lista de referencias
            valores_referencia=referencia[2].split(" ")
            html_tag=valores_referencia[0]
            html_class=None
            html_id=None
            html_type=None

            valores = valores_referencia[1].split('"')
            print(valores)
            if "class=" in valores:
                html_class=valores[valores.index("class=")+1]
            if "id=" in valores:
                html_id=valores[valores.index("id=")+1]
            if "type=" in valores:
                html_type=valores[valores.index("type=")+1]

            print(f"verificando conteúdo de {valores_referencia[1]}:\ntag: {html_tag}\nclasse: {html_class}\nid: {html_id}\ntype: {html_type}")

            if a.find(html_tag, class_=html_class, id=html_id, type=html_type):artigo=a.find(html_tag, class_=html_class, id=html_id, type=html_type)  

            print(f"Texto retirado de {link}\n\n\n{artigo}\n")

            if len(exclusoes)>0:
                excluir=exclusoes.split(";")
                print(f"Exclusoes: {exclusoes}\n")
                for linha in excluir:
                    extag=linha.split(" ")
                    tagname=extag[0]
                    tagtipo=extag.split("=")[0]
                    tagvalor=extag.split("=")[1][1:-1]
                    print(f'>>>>>>>>>>>> Removendo <{tagname} {tagtipo}=""{tagvalor}\n')
                    try:
                        for tag in artigo.find_all(tagname, tagtipo=tagvalor):
                            tag.decompose()
                    except Exception as e:
                        pass

            try:
                texto=(artigo.get_text())
            except Exception as e:
                pass

            if a.find_all("script", type="application/ld+json"):
                artigos= a.find_all("script", type="application/ld+json")
                for artigo in artigos:
                    if "articleBody" in artigo.get_text():
                        texto=(artigo.get_text())


            if "articleBody" in texto:
                parte_texto=texto.split('"')
                i=parte_texto.index("articleBody")
                texto=(parte_texto[i+2])
                texto=re.sub(r'\.', '.\n', texto)

            try: 
                texto_linhas=texto.splitlines()
            except Exception as e:
                pass

            texto_limpo=[]
            exclusoes = [" ", ".","ÁREAS", "Ler Mais", "Luís Montenegro", "António Leitão Amaro", "Vice-presidente do PSD", "Presidente do PSD e líder da Aliança Democrática"]
            exclusoes_parcial = ["por g1","Por g1", "Clique aqui","LEIA TAMBÉM:","Leia também:", "Ler Mais","Marcos Borga","SMA // MAG", "Subscrever","VISÃO Plus","O melhor da semana multimédia: histórias, fotogalerias, videos e podcasts","Newsletter","A subscrição foi submetida com sucesso"]

            #texto_limpo.append(f"--------------------------------------{arquivo}--------------------------------------")
            # texto_limpo.append(f"-------------{link}-------------")
            try:
                for linha in texto_linhas:
                    frases=re.split(r'[.!?]',linha)
                    for frase in frases:
                        # trastes= r'\s+|“|”|\t+|&quot;|Foto:|Fonte:|✅ '
                        #frase=re.sub(trastes,'',frase)
                        frase=re.sub(r'\s+', ' ', frase)
                        frase=re.sub(r'“', '', frase)
                        frase=re.sub(r'”','',frase)
                        frase=re.sub(r'\t+', '', frase)
                        frase=re.sub(r'&quot;', '', frase)
                        frase=re.sub(r'Foto:','',frase)
                        frase=re.sub(r'Fonte:','',frase)
                        frase=re.sub(r'✅ ','',frase)
                        if frase.startswith(r" "):
                            frase=frase[1:]
                        if frase.strip() and frase[0] != '*' and linha not in exclusoes and frase[0].isalpha() and not any(frase.startswith(valor) for valor in exclusoes_parcial):
                            texto_limpo.append(f"{frase}.")
            except Exception as e:
                pass
            #AQUI PODE GRAVAR TUDO EM UM SÓ ARQUIVO
            print(f"\n ----------- Resultado gravado:\n{texto_limpo}\n")
            grava_resultado(texto_limpo,"temp.txt","w","raw_txt")
            grava_resultado(texto_limpo,"TEXTO_SAIDA.txt","a","TEXTO_SAIDA") 
            texto_limpo.clear()

    referencias=carrega_referencias()
    session = requests.Session()

    for item in fontes:
        #print(f'item: {item[2]}\n')
        for ref in referencias:
            if ref[0] in item[2][:len(ref[0])]:
                print(f"Coletando do site: {item[2]} na tag {ref}...\n")
                coleta(item[2], ref, ref[3])
                
                
    #extracao()
    #print("Extração Completa")