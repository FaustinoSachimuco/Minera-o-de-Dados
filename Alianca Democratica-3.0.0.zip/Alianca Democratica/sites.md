|dominio|formato|coletar|isolar|remover|
|-----------|-----------|-----------|-----------|-----------|
|https://rr.sapo.pt|html|div class="all-100" id="bodyDinamico"|||
|https://www.cnnbrasil.com.br|script|||
|https://www.voaportugues.com|html|||
|https://www.rfi.fr|html|html|||
|https://www.dn.pt|html|html|||
|https://www.rtp.pt|html|p itemprop="text" class="article-body"|||
|https://observador.pt|html|div class="article-body-content"|||
|https://www.publico.pt|html|div class="story__body"|||
|https://sicnoticias.pt|script|script id="gs-init-info"|||
|https://eco.sapo.pt|html|div class="entry__content"|||
|https://visao.pt|html|div class="entry-content"|||
|https://capmagellan.com|html|||
|https://www.poder360.com.br|html|<div class="inner-page-section__text">|||
|https://g1.globo.com|html|main class="mc-body theme"|||
|https://cnnportugal.iol.pt|html|div class="article-conteudo" id="articleContent"|||