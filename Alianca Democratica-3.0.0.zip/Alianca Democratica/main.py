from le_arquivo import*
from web_scrapping import*
from pdf_scrapping import*
from analisetexto import*
import subprocess

pdf_scrapping()

extrai_oficial()

extrai_transcricoes()
       
fontes=le_lista_fontes()
extrai_texto(fontes)

analisetexto()