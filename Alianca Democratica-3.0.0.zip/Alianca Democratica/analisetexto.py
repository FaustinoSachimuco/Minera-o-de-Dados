import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from grava_arquivo import*
import re
import spacy

def analisetexto():

    dicionario_exclusoes={}

    nlp = spacy.load("pt_core_news_sm") #python -m spacy download pt_core_news_sm
    nltk.download('punkt')
    nltk.download('vader_lexicon')

    def lematizacao(texto):

        doc = nlp(texto)
        tokens_lema = [token.lemma_ for token in doc]
        return(tokens_lema)
        

    def le_texto_bruto():
        with open('TEXTO_SAIDA/TEXTO_SAIDA.txt', 'r', encoding='utf-8') as file:
            texto = file.read()
            return(texto.splitlines())
    
    def le_exclusoes():
        with open ("palavras_exclusoes.txt", 'r', encoding='utf-8') as txt_exclusoes:
            exclusoes_bruto = txt_exclusoes.read().lower().splitlines()
            for exclusao in exclusoes_bruto:
                lema_exclusao=lematizacao(exclusao)
                if lema_exclusao[0] in dicionario_exclusoes:
                    dicionario_exclusoes[lema_exclusao[0]]=+1
                else:
                    dicionario_exclusoes[lema_exclusao[0]]=1


    def analisesentimento(linhas_texto):
        
        sia = SentimentIntensityAnalyzer()
        
        for linha in linhas_texto:
            frases = nltk.sent_tokenize(linha)
            for frase in frases:
                sentiment_score = sia.polarity_scores(frase)
                #print(f"\n-----------\nFrase:{frase}\nScore Sentimento:{sentiment_score['compound']}")
                if sentiment_score['compound']<0:
                    for palavra in frase.split():
                        sentiment_score_palavra = sia.polarity_scores(palavra)
                        if sentiment_score_palavra['compound']<0 and palavra.lower()!='no' and palavra.lower()!='sob' and palavra.lower()!='(%' and palavra.lower()!='%' and palavra.lower()!='%)':
                            lema_exclusao=lematizacao(palavra)
                            if lema_exclusao[0] in dicionario_exclusoes:
                                dicionario_exclusoes[lema_exclusao[0]]=+1
                            else:
                                dicionario_exclusoes[lema_exclusao[0]]=1
    

    def analisar_etica(linhas_texto):

        limite_ocorrencias = 4
        for frase in linhas_texto:
            violacoes = []
            #pra cada palavra dentro da frase, verificar se coincide com o dicionario
            lemas_frase=lematizacao(frase)
            for lema in lemas_frase:
                if lema in dicionario_exclusoes:
                    violacoes.append(lema)
            if len(violacoes)>limite_ocorrencias:
                print(f'\n--------------------------\nFrase: {frase}\nN. Ocorrências: {len(violacoes)}\nViolações: {violacoes}')
            else:
                grava_resultado(f"{frase}\n","TEXTO_SAIDA_FILTRADO.txt","a","TEXTO_SAIDA") 


    linhas_texto=le_texto_bruto()
    le_exclusoes()
    analisesentimento(linhas_texto)
    analisar_etica(linhas_texto)
