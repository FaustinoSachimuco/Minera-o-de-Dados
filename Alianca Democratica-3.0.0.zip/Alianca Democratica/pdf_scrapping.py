from PyPDF2 import PdfReader
from grava_arquivo import*
import re

def pdf_scrapping():
    texto = ""
    with open("raw/pdf/ad-programa-eleitoral.pdf", "rb") as arquivo:
        leitor_pdf = PdfReader(arquivo)
        num_paginas = len(leitor_pdf.pages)
        novalinha=""
        novo_texto=[]
        for pagina in range(7,num_paginas):
            texto = leitor_pdf.pages[pagina].extract_text()
            texto=re.sub(r' -\n', '', texto)
            texto_pagina=texto.splitlines()
            for linha in texto_pagina:
                if linha.isupper():
                    linha=linha.lower()
                linha=re.sub("• ","",linha)
                if linha.startswith("Executivo") or linha.startswith("eleitoral20") or linha.startswith("programa") or linha[0].isdigit():
                    linha=""
                if linha!="":
                    if linha[0]==" ":
                        linha=linha[1:]
                    if not re.search(r'[.!?:;]+$', linha):
                        novalinha=novalinha+linha
                    else:
                        novalinha=novalinha+" "+linha
                        novo_texto.append(novalinha)
                        novalinha=""
        for linha in novo_texto:
            print(linha)
            grava_resultado(f"{linha}\n","ad-programa-eleitoral.txt","w","raw_txt")
            grava_resultado(f"{linha}\n","TEXTO_SAIDA.txt","a","TEXTO_SAIDA") 